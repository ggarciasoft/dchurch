-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.5-10.0.14-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for dchurch
CREATE DATABASE IF NOT EXISTS `dchurch` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `dchurch`;


-- Dumping structure for function dchurch.GetMemberMinistryPositionsId
DELIMITER //
CREATE DEFINER=`root`@`localhost` FUNCTION `GetMemberMinistryPositionsId`() RETURNS int(11)
BEGIN
DECLARE Id INT unsigned DEFAULT 1;
WHILE 1 = 1 DO
IF (SELECT COUNT(*) FROM memberministrypositions m  WHERE m.Id = Id) = 0 THEN RETURN Id;
ELSE SET Id = Id + 1;
END IF;
END WHILE;
END//
DELIMITER ;


-- Dumping structure for table dchurch.memberministrypositions
CREATE TABLE IF NOT EXISTS `memberministrypositions` (
  `Id` int(11) NOT NULL DEFAULT '0',
  `member_id` int(11) DEFAULT NULL,
  `ministry_id` int(11) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK__ministries` (`ministry_id`),
  KEY `FK__positions` (`position_id`),
  KEY `member_id_ministry_id_position_id` (`member_id`,`ministry_id`,`position_id`),
  CONSTRAINT `FK__members` FOREIGN KEY (`member_id`) REFERENCES `members` (`Id`),
  CONSTRAINT `FK__ministries` FOREIGN KEY (`ministry_id`) REFERENCES `ministries` (`Id`),
  CONSTRAINT `FK__positions` FOREIGN KEY (`position_id`) REFERENCES `positions` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table dchurch.memberministrypositions: ~3 rows (approximately)
/*!40000 ALTER TABLE `memberministrypositions` DISABLE KEYS */;
INSERT INTO `memberministrypositions` (`Id`, `member_id`, `ministry_id`, `position_id`) VALUES
	(3, 1, 2, 1),
	(1, 4, 1, 1),
	(2, 4, 1, 3);
/*!40000 ALTER TABLE `memberministrypositions` ENABLE KEYS */;


-- Dumping structure for table dchurch.members
CREATE TABLE IF NOT EXISTS `members` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `BirthDate` date DEFAULT NULL,
  `ConvertionDate` date DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `HomePhone` varchar(10) DEFAULT NULL,
  `CellPhone` varchar(10) DEFAULT NULL,
  `BaptismDate` date DEFAULT NULL,
  `Active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table dchurch.members: ~2 rows (approximately)
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` (`Id`, `FirstName`, `LastName`, `BirthDate`, `ConvertionDate`, `Address`, `HomePhone`, `CellPhone`, `BaptismDate`, `Active`, `created_at`, `updated_at`) VALUES
	(1, 'Pedro', 'Contreras Sanchez', '1960-10-24', '1975-10-24', 'Sabana Perdida Los Cerros', '', '', '1975-10-24', 1, NULL, '2014-12-17 02:37:20'),
	(4, 'Gregory', 'Garcia', NULL, NULL, '', '', '', NULL, 1, '2014-12-24 21:36:47', '2014-12-24 21:36:47');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;


-- Dumping structure for table dchurch.ministries
CREATE TABLE IF NOT EXISTS `ministries` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(50) NOT NULL,
  `Active` tinyint(1) DEFAULT '1',
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table dchurch.ministries: ~2 rows (approximately)
/*!40000 ALTER TABLE `ministries` DISABLE KEYS */;
INSERT INTO `ministries` (`Id`, `Description`, `Active`, `created_at`, `updated_at`) VALUES
	(1, 'Ministerio de Jovenes', 1, NULL, NULL),
	(2, 'Ministerio General', 1, NULL, '2014-12-07');
/*!40000 ALTER TABLE `ministries` ENABLE KEYS */;


-- Dumping structure for table dchurch.positions
CREATE TABLE IF NOT EXISTS `positions` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(50) NOT NULL,
  `Active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table dchurch.positions: ~3 rows (approximately)
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` (`Id`, `Description`, `Active`, `created_at`, `updated_at`) VALUES
	(1, 'Pastor General', 1, NULL, NULL),
	(2, 'Pastor de Jovenes', 1, NULL, NULL),
	(3, 'Miembro', 1, NULL, NULL);
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;


-- Dumping structure for trigger dchurch.memberministrypositions_before_insert
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `memberministrypositions_before_insert` BEFORE INSERT ON `memberministrypositions` FOR EACH ROW BEGIN
SET NEW.Id = GetMemberMinistryPositionsId();
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
